CREATE DATABASE `passwordHashing` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE TABLE `users` (
    id int NOT NULL AUTO_INCREMENT,
    name varchar(50),
    email varchar(100),
    password varchar(255),
    salt varchar(255),
    PRIMARY KEY (id)
);