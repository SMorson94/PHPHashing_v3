<?php
    $rMsg = "";
    $sMsg = "";
    session_start();
    if(isset($_SESSION['username'])) {
        header('Location: myprofile.php');
    }

    function generateRandomSalt() {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0; $i < 32; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }
        return $randomString;
    }

    //returns a random appending character
    function getRandomPepper() {
        $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        $randomString = $characters[rand(0, $charactersLength - 1)];
        return $randomString;
    }

    if(isset($_POST['register'])) {
        //S1: create connection variable for mysql database (host, username, password, dbname)
        // host(localhost) == the server host
        // username == mysql account username
        // password == password for given username
        // dbname = database name
        $con = new mysqli('localhost', 'root', '', 'passwordHashing');

        //S2: assigning form values to php variables
        //real_escape_string escapes special characters for use in SQL Statement ()
        $name = $con->real_escape_string($_POST['name']);
        $email = $con->real_escape_string($_POST['email']);
        $password = $con->real_escape_string($_POST['password']);
        $cPassword = $con->real_escape_string($_POST['cPassword']);

        //S3: check passwords match:
        if ($password != $cPassword)
        {
            //password is invalid
            //$sMsg is echoed out in div further down this file (line: 93)
            $rMsg = "password mismatch";
        }          
        else {
            //S4: Hash the Password
            $salt = generateRandomSalt();
            $password = $salt . ";" . $password . getRandomPepper(); 
            //$rMsg = $password;
            //TASK 1: ENTER HASH COMMAND
            $password = password_hash($password, PASSWORD_BCRYPT);

            //S5: Insert the new account into the database
            $con->query("INSERT INTO users (name, email, password, salt) VALUES('$name', '$email', '$password', '$salt');");
            
                $_SESSION['username'] = $email;
                header('Location: myprofile.php');
        }

    }

    if(isset($_POST['login'])) {
        //create connection instance
        $con = new mysqli('localhost', 'root', '', 'passwordHashing');

        //assign variables for inputs
        $email = $con->real_escape_string($_POST['sEmail']);
        $password = $con->real_escape_string($_POST['sPassword']);

        //run query checker on email
        $sql = $con->query("SELECT id, salt, password FROM users WHERE LOWER(email)=LOWER('$email');");

        //if user found for email address
        if($sql->num_rows > 0){
            $data = $sql->fetch_array();

            $password = $data['salt'] . ";" . $password;


            $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $charactersLength = strlen($characters);

            $valid = false;

            for ($i = 0; $i < $charactersLength - 1; $i++) {
                $spp = $password . $characters[$i];
                //TASK 2: REPLACE IF STATEMENT CONDITION
                if(password_verify($spp, $data['password']))
                {
                    $_SESSION['username'] = $email;
                    $valid = true;
                    header('Location: myprofile.php');
                }
                
            }

            if($valid == false) {
                $sMsg = "Invalid Password!";
                //$sMsg = $password;
            }

            

        } else {
            //return email not found message
            $sMsg = "Email not registered!";
        }
    }

?>

<!DOCTYPE <!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Password Hashing Tutorial</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.4/css/bulma.min.css">
    <script defer src="https://use.fontawesome.com/releases/v5.3.1/js/all.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <section class="hero is-medium is-light is-bold">
        <div class="hero-body">
            <div class="container">
                <h1 class="title">
                    Account Registration
                </h1>
                <h2 class="subtitle">
                    Password Hashing Tutorial
                </h2>
            </div>
        </div>
        <div class="hero-foot">
            <nav class="tabs">
                <div class="container">
                <ul><li><a class="modal-button" onclick="refs.modalEdicion.open()"> Sign In</a></li>
                <div class="modal" id="modalEdicion">
                    <div class="modal-background" onclick="refs.modalEdicion.close()"></div>
                    <div class="modal-content">
                        <!-- sign in elements -->
                        <form method="post" action="home.php" id="myForm">
                        <div class="section modal-wrap">
                            <div class="field">
                                <p class="control has-icons-left has-icons-right">
                                    <input class="input" type="email" placeholder="Email" name="sEmail">
                                    <span class="icon is-small is-left">
                                    <i class="fas fa-envelope"></i>
                                    </span>
                                    <span class="icon is-small is-right">
                                    <i class="fas fa-check"></i>
                                    </span>
                                </p>
                            </div>
                            <div class="field">
                                <p class="control has-icons-left">
                                    <input class="input" type="password" placeholder="Password" name="sPassword">
                                    <span class="icon is-small is-left">
                                    <i class="fas fa-lock"></i>
                                    </span>
                                </p>
                            </div>
                            <?php 
                                if($sMsg != "") {
                                    echo "<div class=\"notification is-danger\">" . $sMsg . "</div>";
                                } else {
                                    echo '';
                                }
                            ?>
                            <div class="field">
                                <p class="control">
                                    <input class="button is-info" type="submit" value="Sign In" name="login">
                                </p>
                            </div>
                        </div>
                        </form>
                        

                    </div>
                    <button class="modal-close is-large" aria-label="close" onclick="refs.modalEdicion.close()"></button>
                </div>
                </div>
            </nav>
        </div>
    </section>
    <section class="section">
    <div class="container is-widescreen">
  <div class="notification">
    
    <form method="post" action="home.php" id="myForm">
        <div class="field">
            <label class="label">Full Name</label>
            <div class="control has-icons-left">
                <input class="input" type="text" placeholder="e.g. Joseph Bloggs" name="name" minlength="3">
                <span class="icon is-small is-left">
                    <i class="fas fa-user"></i>
                </span>
            </div>
        </div>
        <div class="field">
            <label class="label">Email Address</label>
            <div class="control has-icons-left">
                <input class="input" type="email" placeholder="e.g. joe.bloggs@gmail.com" name="email" minlength="5">
                <span class="icon is-small is-left">
                    <i class="fas fa-envelope"></i>
                </span>
            </div>
        </div>

        <div class="field">
        <label class="label">Password</label>
            <p class="control has-icons-left">
                <input class="input" type="password" placeholder="Must be at least 8 characters long" name="password" minlength="8">
                <span class="icon is-small is-left">
                    <i class="fas fa-lock"></i>
                </span>
            </p>
        </div>
        <div class="field">
        <label class="label">Confirm Password</label>
            <p class="control has-icons-left">
                <input class="input" type="password" placeholder="Must be same as Password above" name="cPassword" minlength="8">
                <span class="icon is-small is-left">
                    <i class="fas fa-lock"></i>
                </span>
            </p>
        </div>
        <?php 
                            if($rMsg != "") {
                                echo "<div class=\"notification is-danger\">The passwords you entered <strong>do not match</strong>.</div>";
                            } else {
                                echo '';
                            }
                        ?>
        <div class="field is-grouped is-grouped-right">
            <p class="control">
                <input class="button is-link" type="submit" value="Register" name="register">
            </p>
        </div>
    </form>
  </div>
</div>
    </section>
    <script type="text/javascript" src="js/modal.js"></script>
</body>
</html>